-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tommydb
-- ------------------------------------------------------
-- Server version	8.0.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `NUM` int NOT NULL AUTO_INCREMENT,
  `PASS` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `NAME` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `WDATE` datetime NOT NULL,
  `TITLE` varchar(40) COLLATE utf8mb3_bin NOT NULL,
  `CONTENT` varchar(100) COLLATE utf8mb3_bin NOT NULL,
  `COUNT` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`NUM`)
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (1,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습1','게시판연습입니다.',4),(2,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습2','게시판연습입니다.',0),(3,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습3','게시판연습입니다.',0),(4,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습4','게시판연습입니다.',0),(6,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습6','게시판연습입니다.',0),(7,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습7','게시판연습입니다.',0),(8,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습8','게시판연습입니다.',0),(9,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습9','게시판연습입니다.',0),(10,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습10','게시판연습입니다.',0),(11,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습11','게시판연습입니다.',0),(12,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습12','게시판연습입니다.',0),(13,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습13','게시판연습입니다.',0),(14,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습14','게시판연습입니다.',0),(15,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습15','게시판연습입니다.',0),(16,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습16','게시판연습입니다.',0),(17,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습17','게시판연습입니다.',0),(18,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습18','게시판연습입니다.',0),(19,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습19','게시판연습입니다.',0),(20,'guest','Mel Gibson','2024-09-25 12:10:18','게시판 연습20','게시판연습입니다.',0),(24,'123','lhj','2024-10-24 14:42:47','새글123','1234567',1),(99,'123','kim','2024-10-25 12:40:08','title','content',0),(990,'123','kim','2024-10-25 13:57:16','title','content',0),(999,'123','kim','2024-10-25 12:42:30','title','content',0);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-29 17:09:26
